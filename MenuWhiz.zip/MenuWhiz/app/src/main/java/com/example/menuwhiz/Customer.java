package com.example.menuwhiz;

public class Customer {
    private String Name;
    private String Email;
    private String Phone;
    private String Password;

    Customer(String name, String email, String phone, String password) {
        this.Name=name;
        this.Email= email;
        this.Phone= phone;
        this.Password= password;
    }
}
