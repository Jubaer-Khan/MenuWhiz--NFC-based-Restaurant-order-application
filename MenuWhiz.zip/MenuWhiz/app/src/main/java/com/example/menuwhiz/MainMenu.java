package com.example.menuwhiz;

import android.app.PendingIntent;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MainMenu extends AppCompatActivity {
    private TextView text;
    private Button signOut;
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    GoogleSignInClient mGoogleSignInClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        text = findViewById(R.id.textView);
        signOut = findViewById(R.id.signOut);

        String serverClientId = getString(R.string.server_client_id);
        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .requestId()
                .requestScopes(new Scope(Scopes.PLUS_ME))
                .requestServerAuthCode(serverClientId)
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter == null) {
            text.setText("Device does not have NFC capabilities");
        } else {
            text.setText("Place phone near NFC Tag");
        }

        pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, this.getClass())
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);


        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignOut();
            }
        });

    }

    private void SignOut() {

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account!= null) {
            mGoogleSignInClient.signOut()
                    .addOnCompleteListener(this, new OnCompleteListener<Void>() {

                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(MainMenu.this, "Sign out succesfull", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    });
        }

        else {
            Intent intent= new Intent(MainMenu.this, LogInActivity.class);
            startActivity(intent);
            Toast.makeText(MainMenu.this, "Sign out succesfull", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(nfcAdapter != null) {
            if (!nfcAdapter.isEnabled())
                showWirelessSettings();

            nfcAdapter.enableForegroundDispatch(this, pendingIntent,null,null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if(nfcAdapter!=null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resolveIntent(intent);
    }

    private void resolveIntent(Intent intent) {
        String action = intent.getAction();
        String hexID = null;

        if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {

                byte[] id = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID);
                Tag tag = (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                byte[] UID = tag.getId();


                hexID = bytesToHexString(UID);

            Intent menuIntent = new Intent(MainMenu.this, RestaurantMenu.class);
            intent.putExtra("nfc",hexID);
            startActivity(menuIntent);
                

            }

            text.setText(hexID);
        }


    public static String bytesToHexString(byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i< bytes.length; i++) {
            int b = bytes[i] & 0xff;

            if (b < 0x10)
                sb.append('0');

            sb.append(Integer.toHexString(b).toUpperCase());
            if (i<=bytes.length-2)
                sb.append(":");
        }
        return sb.toString();
        }
    

    /**private void displayMsgs(NdefMessage[] msgs) {

        if (msgs == null || msgs.length==0)
            return;

        StringBuilder builder = new StringBuilder();
        List<ParsedNdefRecord>
    }**/

    private void showWirelessSettings() {
        Toast.makeText(this, "You need to enable NFC", Toast.LENGTH_SHORT).show();
        Intent intent= new Intent(Settings.ACTION_WIRELESS_SETTINGS);

        startActivity(intent);
    }


}


